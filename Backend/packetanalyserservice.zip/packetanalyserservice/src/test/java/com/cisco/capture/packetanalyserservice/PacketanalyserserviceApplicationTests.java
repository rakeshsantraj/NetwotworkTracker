package com.cisco.capture.packetanalyserservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PacketanalyserserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
