package com.cisco.capture.packetanalyserservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PacketanalyserserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PacketanalyserserviceApplication.class, args);
	}

}
