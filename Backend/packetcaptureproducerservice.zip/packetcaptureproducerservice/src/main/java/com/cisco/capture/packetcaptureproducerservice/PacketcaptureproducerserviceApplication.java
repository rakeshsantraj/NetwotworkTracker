package com.cisco.capture.packetcaptureproducerservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PacketcaptureproducerserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PacketcaptureproducerserviceApplication.class, args);
	}

}
