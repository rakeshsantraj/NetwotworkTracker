package com.cisco.capture.packetcaptureproducerservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PacketcaptureproducerserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
