package com.cisco.capture.packetcaptureconsumerservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PacketcaptureconsumerserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PacketcaptureconsumerserviceApplication.class, args);
	}

}
