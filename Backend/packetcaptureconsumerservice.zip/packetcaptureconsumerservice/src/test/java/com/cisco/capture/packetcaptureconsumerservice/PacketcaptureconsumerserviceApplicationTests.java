package com.cisco.capture.packetcaptureconsumerservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PacketcaptureconsumerserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
